#!/usr/bin/env node
'use strict';
const fs = require('fs');
const path = require('path');
const root = path.resolve(process.argv[2] || process.cwd());
const ignored = new Set(['.git','node_modules','.vscode','dist','build']);
let files = 0, warnings = 0, readErrors = 0;
function emit(file, line, column, message) {
  const relative = path.relative(root, file).replace(/\\/g, '/');
  process.stdout.write(`${relative}:${line}:${column}: warning: ${message}\n`);
  warnings++;
}
function scan(file) {
  let text;
  try { text = fs.readFileSync(file, 'utf8'); } catch(e) { console.error(`読み込み失敗: ${file}: ${e.message}`); readErrors++; return; }
  files++;
  // Heuristic: FTL comments are not nestable. When a second opener appears
  // before the first closer, flag it. A later closer cannot prove intent.
  let inside = false, pos = 0, line = 1, col = 1;
  const token = /<#--|-->/g;
  let m;
  while ((m = token.exec(text))) {
    const between = text.slice(pos, m.index);
    const parts = between.split(/\r\n|\r|\n/);
    if (parts.length > 1) { line += parts.length - 1; col = parts[parts.length - 1].length + 1; }
    else col += between.length;
    const atLine = line, atCol = col;
    if (m[0] === '<#--') {
      if (inside) emit(file, atLine, atCol, 'FTLコメント内に別の <#-- があります（ネスト疑い）');
      else inside = true;
    } else if (inside) inside = false;
    pos = m.index + m[0].length;
    col += m[0].length;
  }
}
function walk(dir) {
  let entries;
  try { entries = fs.readdirSync(dir, {withFileTypes:true}); } catch(e) { console.error(`フォルダ読み込み失敗: ${dir}: ${e.message}`); readErrors++; return; }
  for (const ent of entries) {
    const full = path.join(dir, ent.name);
    if (ent.isDirectory() && !ignored.has(ent.name)) walk(full);
    else if (ent.isFile() && /\.ftl$/i.test(ent.name)) scan(full);
  }
}
if (!fs.existsSync(root) || !fs.statSync(root).isDirectory()) { console.error(`対象フォルダがありません: ${root}`); process.exit(2); }
walk(root);
console.log(`FTLチェック完了: ${files}ファイル / ネスト疑い${warnings}件 / 読み込みエラー${readErrors}件`);
process.exitCode = readErrors ? 2 : 0;
